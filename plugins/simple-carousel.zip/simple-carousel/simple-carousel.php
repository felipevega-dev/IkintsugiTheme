<?php
/**
 * Plugin Name: Simple Carousel Test
 * Description: Un carrusel simple para probar compatibilidad con Sage
 * Version: 1.0.0
 * Author: Test
 */

if (!defined('WPINC')) {
    die;
}

class Simple_Carousel {
    private $version = '1.0.0';
    private $plugin_name = 'simple-carousel';

    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('init', array($this, 'register_carousel_post_type'));
        add_shortcode('simple_carousel', array($this, 'render_carousel'));
    }

    public function register_carousel_post_type() {
        register_post_type('carousel_item', array(
            'labels' => array(
                'name' => __('Carousel Items'),
                'singular_name' => __('Carousel Item'),
                'add_new' => __('Add New'),
                'add_new_item' => __('Add New Item'),
                'edit_item' => __('Edit Item'),
                'new_item' => __('New Item'),
                'view_item' => __('View Item'),
                'search_items' => __('Search Items'),
                'not_found' => __('No items found'),
                'not_found_in_trash' => __('No items found in Trash')
            ),
            'public' => true,
            'show_in_menu' => false,
            'supports' => array('title', 'editor', 'thumbnail'),
            'menu_position' => 20,
            'has_archive' => false
        ));

        // Registrar campos personalizados
        add_action('add_meta_boxes', array($this, 'add_carousel_meta_boxes'));
        add_action('save_post_carousel_item', array($this, 'save_carousel_meta'));
    }

    public function add_carousel_meta_boxes() {
        add_meta_box(
            'carousel_item_details',
            __('Item Details'),
            array($this, 'render_item_details_meta_box'),
            'carousel_item',
            'normal',
            'high'
        );
    }

    public function render_item_details_meta_box($post) {
        wp_nonce_field('carousel_meta_box', 'carousel_meta_box_nonce');

        $type = get_post_meta($post->ID, '_carousel_item_type', true);
        $video_url = get_post_meta($post->ID, '_video_url', true);
        $link_url = get_post_meta($post->ID, '_link_url', true);
        ?>
        <style>
            .carousel-meta-box { padding: 10px 0; }
            .carousel-meta-box label { display: block; margin-bottom: 5px; font-weight: bold; }
            .carousel-meta-box input[type="text"] { width: 100%; margin-bottom: 15px; }
            .carousel-meta-box .type-fields { margin-top: 15px; }
        </style>

        <div class="carousel-meta-box">
            <label>
                <input type="radio" name="carousel_item_type" value="image" <?php checked($type, 'image'); ?> <?php checked($type, ''); ?>>
                <?php _e('Image with Link'); ?>
            </label>
            <label>
                <input type="radio" name="carousel_item_type" value="video" <?php checked($type, 'video'); ?>>
                <?php _e('Video'); ?>
            </label>

            <div class="type-fields" id="video-fields" style="display: <?php echo ($type === 'video' ? 'block' : 'none'); ?>">
                <label for="video_url"><?php _e('Video URL (YouTube or Vimeo)'); ?></label>
                <input type="text" id="video_url" name="video_url" value="<?php echo esc_attr($video_url); ?>">
            </div>

            <div class="type-fields" id="link-fields" style="display: <?php echo ($type !== 'video' ? 'block' : 'none'); ?>">
                <label for="link_url"><?php _e('Link URL'); ?></label>
                <input type="text" id="link_url" name="link_url" value="<?php echo esc_attr($link_url); ?>">
            </div>
        </div>

        <script>
            jQuery(document).ready(function($) {
                $('input[name="carousel_item_type"]').on('change', function() {
                    const type = $(this).val();
                    $('#video-fields').toggle(type === 'video');
                    $('#link-fields').toggle(type === 'image');
                });
            });
        </script>
        <?php
    }

    public function save_carousel_meta($post_id) {
        if (!isset($_POST['carousel_meta_box_nonce'])) {
            return;
        }

        if (!wp_verify_nonce($_POST['carousel_meta_box_nonce'], 'carousel_meta_box')) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        // Guardar tipo de item
        if (isset($_POST['carousel_item_type'])) {
            update_post_meta($post_id, '_carousel_item_type', sanitize_text_field($_POST['carousel_item_type']));
        }

        // Guardar URL del video
        if (isset($_POST['video_url'])) {
            update_post_meta($post_id, '_video_url', esc_url_raw($_POST['video_url']));
        }

        // Guardar URL del enlace
        if (isset($_POST['link_url'])) {
            update_post_meta($post_id, '_link_url', esc_url_raw($_POST['link_url']));
        }
    }

    public function enqueue_admin_assets($hook) {
        if ('carousel_page_simple-carousel-settings' !== $hook) {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_style(
            'simple-carousel-admin',
            plugins_url('admin/css/admin.css', __FILE__),
            array(),
            $this->version
        );

        wp_enqueue_script(
            'simple-carousel-admin',
            plugins_url('admin/js/admin.js', __FILE__),
            array('jquery', 'jquery-ui-sortable'),
            $this->version,
            true
        );

        wp_localize_script('simple-carousel-admin', 'simpleCarousel', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('simple_carousel_nonce')
        ));
    }

    public function enqueue_assets() {
        // Registrar estilos
        wp_register_style(
            'simple-carousel-style',
            plugins_url('css/carousel.css', __FILE__),
            array(),
            $this->version
        );

        // Registrar scripts
        wp_register_script(
            'simple-carousel-script',
            plugins_url('js/carousel.js', __FILE__),
            array('jquery'),
            $this->version,
            true
        );
    }

    public function add_admin_menu() {
        add_menu_page(
            __('Carousel Manager'),
            __('Carousel'),
            'manage_options',
            'simple-carousel',
            array($this, 'display_admin_page'),
            'dashicons-images-alt2',
            20
        );

        add_submenu_page(
            'simple-carousel',
            __('Add New Item'),
            __('Add New Item'),
            'manage_options',
            'post-new.php?post_type=carousel_item'
        );

        add_submenu_page(
            'simple-carousel',
            __('Settings'),
            __('Settings'),
            'manage_options',
            'simple-carousel-settings',
            array($this, 'display_settings_page')
        );
    }

    public function display_admin_page() {
        include plugin_dir_path(__FILE__) . 'admin/partials/admin-display.php';
    }

    public function display_settings_page() {
        include plugin_dir_path(__FILE__) . 'admin/partials/settings-display.php';
    }

    public function render_carousel($atts) {
        // Cargar estilos y scripts solo cuando se usa el shortcode
        wp_enqueue_style('simple-carousel-style');
        wp_enqueue_script('simple-carousel-script');

        $args = array(
            'post_type' => 'carousel_item',
            'posts_per_page' => -1,
            'orderby' => 'menu_order',
            'order' => 'ASC'
        );

        $items = get_posts($args);
        
        ob_start();
        ?>
        <div class="simple-carousel">
            <div class="simple-carousel-wrapper">
                <?php foreach ($items as $item): 
                    $type = get_post_meta($item->ID, '_carousel_item_type', true);
                    $type = $type ?: 'image';
                    
                    if ($type === 'video'):
                        $video_url = get_post_meta($item->ID, '_video_url', true);
                        $video_id = '';
                        
                        // Extraer ID del video de YouTube o Vimeo
                        if (strpos($video_url, 'youtube.com') !== false || strpos($video_url, 'youtu.be') !== false) {
                            preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/', $video_url, $matches);
                            if (isset($matches[1])) {
                                $video_id = $matches[1];
                                $embed_url = "https://www.youtube.com/embed/{$video_id}";
                            }
                        } elseif (strpos($video_url, 'vimeo.com') !== false) {
                            preg_match('/vimeo\.com\/([0-9]+)/', $video_url, $matches);
                            if (isset($matches[1])) {
                                $video_id = $matches[1];
                                $embed_url = "https://player.vimeo.com/video/{$video_id}";
                            }
                        }
                ?>
                    <div class="simple-carousel-slide video-slide">
                        <?php if ($video_id): ?>
                            <iframe src="<?php echo esc_url($embed_url); ?>" 
                                    frameborder="0" 
                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                                    allowfullscreen></iframe>
                        <?php endif; ?>
                        <div class="simple-carousel-caption">
                            <h3><?php echo esc_html($item->post_title); ?></h3>
                            <?php if (!empty($item->post_content)): ?>
                                <p><?php echo esc_html($item->post_content); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php else:
                    $image_url = get_the_post_thumbnail_url($item->ID, 'full');
                    $link_url = get_post_meta($item->ID, '_link_url', true);
                    if (!$image_url) continue;
                ?>
                    <div class="simple-carousel-slide image-slide">
                        <?php if ($link_url): ?>
                            <a href="<?php echo esc_url($link_url); ?>" target="_blank">
                        <?php endif; ?>
                            <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($item->post_title); ?>">
                        <?php if ($link_url): ?>
                            </a>
                        <?php endif; ?>
                        <div class="simple-carousel-caption">
                            <h3><?php echo esc_html($item->post_title); ?></h3>
                            <?php if (!empty($item->post_content)): ?>
                                <p><?php echo esc_html($item->post_content); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
                <?php endforeach; ?>
            </div>
            <button class="simple-carousel-prev">←</button>
            <button class="simple-carousel-next">→</button>
        </div>
        <?php
        return ob_get_clean();
    }
}

new Simple_Carousel(); 