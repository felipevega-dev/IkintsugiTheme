<?php
if (!defined('ABSPATH')) exit;

$settings = get_option('simple_carousel_settings', array(
    'autoplay' => true,
    'autoplay_speed' => 3000,
    'transition_speed' => 300,
    'show_arrows' => true,
    'show_dots' => true
));
?>

<div class="wrap">
    <h1><?php _e('Carousel Settings'); ?></h1>
    
    <form method="post" action="options.php">
        <?php settings_fields('simple-carousel-settings'); ?>
        
        <table class="form-table">
            <tr>
                <th scope="row"><?php _e('Autoplay'); ?></th>
                <td>
                    <label>
                        <input type="checkbox" name="simple_carousel_settings[autoplay]" 
                               value="1" <?php checked($settings['autoplay'], 1); ?>>
                        <?php _e('Enable autoplay'); ?>
                    </label>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><?php _e('Autoplay Speed'); ?></th>
                <td>
                    <input type="number" name="simple_carousel_settings[autoplay_speed]" 
                           value="<?php echo esc_attr($settings['autoplay_speed']); ?>" min="1000" step="500">
                    <p class="description"><?php _e('Time between slides in milliseconds (minimum 1000ms)'); ?></p>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><?php _e('Transition Speed'); ?></th>
                <td>
                    <input type="number" name="simple_carousel_settings[transition_speed]" 
                           value="<?php echo esc_attr($settings['transition_speed']); ?>" min="100" step="100">
                    <p class="description"><?php _e('Slide transition speed in milliseconds'); ?></p>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><?php _e('Navigation'); ?></th>
                <td>
                    <label>
                        <input type="checkbox" name="simple_carousel_settings[show_arrows]" 
                               value="1" <?php checked($settings['show_arrows'], 1); ?>>
                        <?php _e('Show navigation arrows'); ?>
                    </label>
                    <br>
                    <label>
                        <input type="checkbox" name="simple_carousel_settings[show_dots]" 
                               value="1" <?php checked($settings['show_dots'], 1); ?>>
                        <?php _e('Show navigation dots'); ?>
                    </label>
                </td>
            </tr>
        </table>
        
        <?php submit_button(); ?>
    </form>
</div> 