<?php
if (!defined('ABSPATH')) exit;

$carousel_items = get_posts(array(
    'post_type' => 'carousel_item',
    'posts_per_page' => -1,
    'orderby' => 'menu_order',
    'order' => 'ASC'
));
?>

<div class="wrap">
    <h1 class="wp-heading-inline"><?php _e('Carousel Manager'); ?></h1>
    <a href="<?php echo admin_url('post-new.php?post_type=carousel_item'); ?>" class="page-title-action"><?php _e('Add New Item'); ?></a>
    
    <div class="carousel-items-grid">
        <?php if (!empty($carousel_items)): ?>
            <?php foreach ($carousel_items as $item): 
                $image_url = get_the_post_thumbnail_url($item->ID, 'medium');
            ?>
                <div class="carousel-item-card">
                    <div class="carousel-item-image">
                        <?php if ($image_url): ?>
                            <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($item->post_title); ?>">
                        <?php else: ?>
                            <div class="no-image"><?php _e('No Image'); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="carousel-item-details">
                        <h3><?php echo esc_html($item->post_title); ?></h3>
                        <div class="carousel-item-actions">
                            <a href="<?php echo get_edit_post_link($item->ID); ?>" class="button"><?php _e('Edit'); ?></a>
                            <a href="<?php echo get_delete_post_link($item->ID); ?>" class="button delete"><?php _e('Delete'); ?></a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="no-items">
                <p><?php _e('No carousel items found.'); ?></p>
                <a href="<?php echo admin_url('post-new.php?post_type=carousel_item'); ?>" class="button button-primary"><?php _e('Add Your First Item'); ?></a>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="carousel-shortcode-info">
        <h2><?php _e('How to Use'); ?></h2>
        <p><?php _e('Use this shortcode to display the carousel in your posts or pages:'); ?></p>
        <code>[simple_carousel]</code>
    </div>
</div> 