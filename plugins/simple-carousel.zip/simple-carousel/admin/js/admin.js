jQuery(document).ready(function($) {
    // Initialize sortable for carousel items
    $('.carousel-items-grid').sortable({
        items: '.carousel-item-card',
        handle: '.carousel-item-image',
        cursor: 'move',
        opacity: 0.7,
        revert: true,
        update: function(event, ui) {
            const items = [];
            $('.carousel-item-card').each(function() {
                items.push($(this).data('id'));
            });

            $.ajax({
                url: simpleCarousel.ajaxurl,
                type: 'POST',
                data: {
                    action: 'update_carousel_order',
                    items: items,
                    nonce: simpleCarousel.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Optional: Show success message
                    }
                }
            });
        }
    });

    // Confirm delete action
    $('.carousel-item-actions .delete').on('click', function(e) {
        if (!confirm('Are you sure you want to delete this item?')) {
            e.preventDefault();
        }
    });
}); 