class SimpleCarousel {
    constructor(element) {
        this.carousel = element;
        this.wrapper = element.querySelector('.simple-carousel-wrapper');
        this.slides = Array.from(element.querySelectorAll('.simple-carousel-slide'));
        this.prevBtn = element.querySelector('.simple-carousel-prev');
        this.nextBtn = element.querySelector('.simple-carousel-next');
        this.currentIndex = 0;
        
        this.init();
    }
    
    init() {
        this.prevBtn.addEventListener('click', () => this.prev());
        this.nextBtn.addEventListener('click', () => this.next());
        
        // Optional: Add touch/swipe support
        let startX, moveX;
        this.wrapper.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
        });
        
        this.wrapper.addEventListener('touchmove', (e) => {
            moveX = e.touches[0].clientX;
        });
        
        this.wrapper.addEventListener('touchend', () => {
            if (startX - moveX > 50) this.next();
            if (startX - moveX < -50) this.prev();
        });
    }
    
    prev() {
        this.currentIndex = (this.currentIndex - 1 + this.slides.length) % this.slides.length;
        this.updateCarousel();
    }
    
    next() {
        this.currentIndex = (this.currentIndex + 1) % this.slides.length;
        this.updateCarousel();
    }
    
    updateCarousel() {
        const offset = -this.currentIndex * 100;
        this.wrapper.style.transform = `translateX(${offset}%)`;
    }
}

// Initialize all carousels on the page
document.addEventListener('DOMContentLoaded', () => {
    const carousels = document.querySelectorAll('.simple-carousel');
    carousels.forEach(carousel => new SimpleCarousel(carousel));
}); 